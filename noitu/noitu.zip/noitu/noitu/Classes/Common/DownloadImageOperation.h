//
//  DownloadImageOperation.h
//  1word2pics
//
//  Created by Hoang le on 4/15/13.
//  Copyright (c) 2013 Hoang le. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"
#import "Common.h"

@interface DownloadImageOperation : NSOperation

@end
