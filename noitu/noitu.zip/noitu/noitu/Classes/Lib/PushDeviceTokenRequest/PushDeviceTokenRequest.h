//
//  PushDeviceTokenRequest.h
//  1word2pics
//
//  Created by Hoang le on 5/15/13.
//  Copyright (c) 2013 Hoang le. All rights reserved.
//

#import "ASIHTTPRequest.h"
#import <Foundation/Foundation.h>

@interface PushDeviceTokenRequest : ASIHTTPRequest



@end
