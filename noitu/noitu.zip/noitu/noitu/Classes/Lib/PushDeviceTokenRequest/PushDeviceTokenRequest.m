//
//  PushDeviceTokenRequest.m
//  1word2pics
//
//  Created by Hoang le on 5/15/13.
//  Copyright (c) 2013 Hoang le. All rights reserved.
//

#import "PushDeviceTokenRequest.h"

@implementation PushDeviceTokenRequest

@end
