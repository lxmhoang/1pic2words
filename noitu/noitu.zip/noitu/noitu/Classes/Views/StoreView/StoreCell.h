//
//  StoreCell.h
//  1word2pics
//
//  Created by Hoang Le on 5/11/13.
//  Copyright (c) 2013 Hoang le. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StoreCell : UITableViewCell

- (void)showPrice:(NSString *)_amount saving:(NSString *)_saving;

@end
