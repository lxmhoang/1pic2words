//
//  RootModel.m
//  noitu
//
//  Created by Hoang le on 3/20/13.
//  Copyright (c) 2013 Hoang le. All rights reserved.
//

#import "RootModel.h"

@implementation RootModel

@end
